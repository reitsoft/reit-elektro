<script>
	export let data;
	const { project } = data;
</script>

<pre class="text-white">
  {JSON.stringify(project, undefined, 4)}
</pre>
