<script>
	import { Heading } from '$lib';
</script>

<Heading text="Einheiten" />
